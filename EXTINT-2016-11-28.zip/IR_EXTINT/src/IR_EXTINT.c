/*
===============================================================================
 Name        : IR_EXTINT.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#include "timer.h"
#include "uart.h"
#include "extint.h"
#include "type.h"
#include <time.h>
#endif

#include <cr_section_macros.h>

#include <stdio.h>
// TODO: insert other include files here

// TODO: insert other definitions and declarations here

extern uint32_t timer0_m0_counter, timer1_m0_counter;
extern uint32_t timer0_m1_counter, timer1_m1_counter;

int main(void)
{

	LPC_GPIO0->FIODIR |= (1<<3); //set pin 0.23 as output
	LPC_GPIO0->FIODIR &= ~(1<<11); //set pin 2.11 as input
	LPC_GPIO0->FIOCLR |= (1<<3); //clear pin 0.23

while(1)
{
	EINTInit();   //wait for external interrupt
}

  return 0;
}
